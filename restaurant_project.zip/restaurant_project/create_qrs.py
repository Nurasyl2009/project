import qrcode
import os

# ТҮЗЕТУ: соңына :8000 қосыңыз
BASE_URL = "http://10.202.8.232:8000"

tables = ["1", "2", "3", "4", "5", "6", "7", "8"]

if not os.path.exists("qrcodes"):
    os.makedirs("qrcodes")

print("--- QR КОДТАР ЖАСАЛУДА ---")

for table_id in tables:
    # Енді сілтеме http://172.20.10.13:8000/qr/1 болады
    link = f"{BASE_URL}/qr/{table_id}"
    
    qr = qrcode.QRCode(box_size=10, border=5)
    qr.add_data(link)
    qr.make(fit=True)
    
    img = qr.make_image(fill="black", back_color="white")
    
    filename = f"qrcodes/table_{table_id}.png"
    img.save(filename)
    print(f"✅ Сақталды: {filename} -> {link}")