from __future__ import annotations
import shutil
import os
import time
import json
import csv
import io
from pathlib import Path
from datetime import datetime, date, timedelta
from typing import List, Optional, Dict, Generator, Any

from fastapi import (
    FastAPI,
    Depends,
    HTTPException,
    status,
    Query,
    Request,
    Form,
    WebSocket,
    WebSocketDisconnect,
    UploadFile,
    File,
)
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse, RedirectResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from flask import request
from starlette.middleware.sessions import SessionMiddleware

from pydantic import BaseModel, Field

from sqlalchemy import (
    create_engine,
    Column,
    String,
    Integer,
    Float,
    Date,
    DateTime,
    Boolean,
    ForeignKey,
    Text,
    func,
    text,
)
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import (
    declarative_base,
    relationship,
    sessionmaker,
    Session,
    selectinload,
)

# ---------------------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------------------

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql+psycopg2://postgres:1234@localhost:1234/proverka")
SESSION_SECRET = os.getenv("SESSION_SECRET", "super-secret-key-change-me")

engine = create_engine(DATABASE_URL, echo=False, future=True, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

# Custom Jinja Filter
def kz_time_filter(dt):
    if not dt:
        return ""
    # Adjust time zone if necessary, otherwise assuming server time is correct or handled
    return (dt + timedelta(hours=5)).strftime('%H:%M')

templates.env.filters["kz_time"] = kz_time_filter

ROLE_PERMS: Dict[str, set[str]] = {
    "admin": {
        "menu.edit", "payroll.edit", "users.manage", "inventory.move",
        "inventory.view", "analytics.view", "discount.edit", "shift.manage",
        "shift.self", "suppliers.manage", "po.manage", "orders.create",
        "orders.status", "tables.status",
    },
    "manager": {
        "inventory.move", "inventory.view", "analytics.view", "discount.edit",
        "shift.manage", "shift.self", "suppliers.manage", "po.manage",
        "orders.status", "tables.status",
    },
    "waiter": {
        "orders.create", "orders.status", "tables.status", "shift.self",
        "inventory.view",
    },
    "chef": {
        "orders.status", "shift.self", "inventory.view",
    },
}

# ---------------------------------------------------------------------------
# DATABASE MODELS
# ---------------------------------------------------------------------------

class Announcement(Base):
    __tablename__ = "announcements"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    message = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class Promotion(Base):
    __tablename__ = "promotions"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    title = Column(String, nullable=False)
    description = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)

class SystemUser(Base):
    __tablename__ = "auth_users"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    username = Column(String, unique=True, nullable=False, index=True)
    password = Column(String, nullable=False)
    role = Column(String, nullable=False)

class Employee(Base):
    __tablename__ = "employees"
    id = Column(String, primary_key=True, index=True)
    username = Column(String, nullable=False)
    role = Column(String, nullable=False)
    hourly_rate = Column(Integer, nullable=False)

    attendance_records = relationship("Attendance", back_populates="employee", cascade="all, delete-orphan")
    payroll_records = relationship("PayrollRecord", back_populates="employee", cascade="all, delete-orphan")
    shifts = relationship("Shift", back_populates="employee", cascade="all, delete-orphan")

class Attendance(Base):
    __tablename__ = "attendance"
    id = Column(String, primary_key=True, index=True)
    user_id = Column(String, ForeignKey("employees.id"), nullable=False)
    date = Column(Date, nullable=False)
    total_hours = Column(Float, nullable=False)
    employee = relationship("Employee", back_populates="attendance_records")

class PayrollRecord(Base):
    __tablename__ = "payroll"
    id = Column(String, primary_key=True, index=True)
    user_id = Column(String, ForeignKey("employees.id"), nullable=False)
    username = Column(String, nullable=False)
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)
    total_hours = Column(Float, nullable=False)
    total_amount = Column(Integer, nullable=False)
    status = Column(String, nullable=False)
    employee = relationship("Employee", back_populates="payroll_records")

class Customer(Base):
    __tablename__ = "customers"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    phone = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=True)
    bonus_balance = Column(Integer, default=0)
    visits_count = Column(Integer, default=0)
    last_visit = Column(Date, nullable=True)
    orders = relationship("Order", back_populates="customer")

class Reservation(Base):
    __tablename__ = "reservations"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    customer_name = Column(String, nullable=False)
    customer_phone = Column(String, nullable=False)
    time_start = Column(DateTime, nullable=False)
    guests_count = Column(Integer, default=2)
    comment = Column(String, nullable=True)
    status = Column(String, default="active")

class Table(Base):
    __tablename__ = "tables"
    id = Column(String, primary_key=True, index=True)
    room = Column(String, nullable=False)
    number = Column(Integer, nullable=False)
    status = Column(String, nullable=False, default="free")
    current_order_id = Column(String, nullable=True)
    x = Column(Integer, default=50)
    y = Column(Integer, default=50)
    orders = relationship("Order", back_populates="table")

class Feedback(Base):
    __tablename__ = "feedback"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    order_id = Column(String, ForeignKey("orders.id"), nullable=False)
    rating = Column(Integer, nullable=False)
    comment = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class MenuItem(Base):
    __tablename__ = "menu_items"
    id = Column(String, primary_key=True, index=True)
    name = Column(String, nullable=False)
    category = Column(String, nullable=False)
    price = Column(Integer, nullable=False)
    description = Column(Text, nullable=False)
    image = Column(String, nullable=True)
    popular = Column(Boolean, nullable=False, default=False)
    discount_percent = Column(Integer, default=0) 
    recipe_items = relationship("RecipeIngredient", back_populates="menu_item", cascade="all, delete-orphan")

class Order(Base):
    __tablename__ = "orders"
    id = Column(String, primary_key=True, index=True)
    table_id = Column(String, ForeignKey("tables.id"), nullable=False)
    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=True)
    status = Column(String, nullable=False, default="new")
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    total_amount = Column(Integer, default=0)
    discount_amount = Column(Integer, default=0)
    final_amount = Column(Integer, default=0)
    cooking_at = Column(DateTime, nullable=True)
    ready_at = Column(DateTime, nullable=True)
    delivered_at = Column(DateTime, nullable=True)
    waiter_name = Column(String, nullable=False)

    table = relationship("Table", back_populates="orders")
    items = relationship("OrderItem", back_populates="order", cascade="all, delete-orphan")
    customer = relationship("Customer", back_populates="orders")

class DailyReport(Base):
    __tablename__ = "daily_reports"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    date = Column(Date, nullable=False, default=datetime.utcnow().date)
    total_revenue = Column(Integer, default=0)
    bonuses_used = Column(Integer, default=0)
    orders_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

class OrderItem(Base):
    __tablename__ = "order_items"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    order_id = Column(String, ForeignKey("orders.id"), nullable=False)
    menu_item_id = Column(String, ForeignKey("menu_items.id"), nullable=False)
    quantity = Column(Integer, nullable=False)
    order = relationship("Order", back_populates="items")
    menu_item = relationship("MenuItem")

class InventoryItem(Base):
    __tablename__ = "inventory_items"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String, nullable=False)
    sku = Column(String, unique=True, nullable=True)
    unit = Column(String, nullable=False, default="kg")
    quantity = Column(Float, nullable=False, default=0.0)
    min_quantity = Column(Float, nullable=False, default=0.0)
    cost_per_unit = Column(Float, nullable=True)
    recipe_items = relationship("RecipeIngredient", back_populates="inventory_item", cascade="all, delete-orphan")
    movements = relationship("InventoryMovement", back_populates="item", cascade="all, delete-orphan")

class RecipeIngredient(Base):
    __tablename__ = "recipe_ingredients"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    menu_item_id = Column(String, ForeignKey("menu_items.id"), nullable=False)
    inventory_item_id = Column(Integer, ForeignKey("inventory_items.id"), nullable=False)
    quantity_per_unit = Column(Float, nullable=False)
    menu_item = relationship("MenuItem", back_populates="recipe_items")
    inventory_item = relationship("InventoryItem", back_populates="recipe_items")

class InventoryMovement(Base):
    __tablename__ = "inventory_movements"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    item_id = Column(Integer, ForeignKey("inventory_items.id"), nullable=False)
    movement_type = Column(String, nullable=False) # in|out|waste|adjust
    quantity = Column(Float, nullable=False)
    reason = Column(String, nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    created_by = Column(String, nullable=True)
    item = relationship("InventoryItem", back_populates="movements")

class Shift(Base):
    __tablename__ = "shifts"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(String, ForeignKey("employees.id"), nullable=False)
    start_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    end_at = Column(DateTime, nullable=True)
    status = Column(String, nullable=False, default="open") # open|closed
    employee = relationship("Employee", back_populates="shifts")

class Supplier(Base):
    __tablename__ = "suppliers"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String, nullable=False)
    phone = Column(String, nullable=True)
    purchase_orders = relationship("PurchaseOrder", back_populates="supplier")

class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"), nullable=False)
    status = Column(String, nullable=False, default="draft")
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    received_at = Column(DateTime, nullable=True)
    supplier = relationship("Supplier", back_populates="purchase_orders")
    items = relationship("PurchaseOrderItem", back_populates="po", cascade="all, delete-orphan")

class PurchaseOrderItem(Base):
    __tablename__ = "purchase_order_items"
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    po_id = Column(Integer, ForeignKey("purchase_orders.id"), nullable=False)
    item_id = Column(Integer, ForeignKey("inventory_items.id"), nullable=False)
    quantity = Column(Float, nullable=False)
    price_per_unit = Column(Float, nullable=True)
    po = relationship("PurchaseOrder", back_populates="items")
    item = relationship("InventoryItem")

# ---------------------------------------------------------------------------
# FASTAPI APP
# ---------------------------------------------------------------------------

app = FastAPI(title="Restaurant CRM", version="2.2.0")
app.mount("/static", StaticFiles(directory="static"), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(SessionMiddleware, secret_key=SESSION_SECRET)

# ---------------------------------------------------------------------------
# WEBSOCKETS
# ---------------------------------------------------------------------------

class ConnectionManager:
    def __init__(self) -> None:
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket) -> None:
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket) -> None:
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast(self, message: str) -> None:
        dead: List[WebSocket] = []
        for ws in self.active_connections:
            try:
                await ws.send_text(message)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)

ws_manager = ConnectionManager()

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)

def ws_json(payload: Dict[str, Any]) -> str:
    return json.dumps(payload, ensure_ascii=False)

# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------

def get_current_shift(db: Session, user_id: str):
    return db.query(Shift).filter(Shift.user_id == user_id, Shift.status == "open").first()

def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_lang(request: Request) -> str:
    lang = (request.cookies.get("lang", "kk") or "kk").lower()
    if lang not in ("kk", "ru", "en"):
        lang = "kk"
    return lang

def get_current_user(request: Request) -> Optional[Dict[str, Any]]:
    return request.session.get("user")

def require_role(allowed_roles: List[str]):
    def _dep(request: Request):
        user = get_current_user(request)
        if not user or user.get("role") not in allowed_roles:
            raise HTTPException(status_code=403, detail="Access forbidden")
        return user
    return _dep

def require_perm(perm: str):
    def _dep(request: Request):
        user = get_current_user(request)
        if not user:
            raise HTTPException(status_code=403, detail="Not authenticated")
        role = (user.get("role") or "").lower()
        if perm not in ROLE_PERMS.get(role, set()):
            raise HTTPException(status_code=403, detail=f"Forbidden: missing perm {perm}")
        return user
    return _dep

def get_employee_for_session_user(db: Session, user: Dict[str, Any]) -> Optional[Employee]:
    uname = user.get("username")
    if not uname:
        return None
    return db.query(Employee).filter(Employee.username == uname).first()

def apply_movement(item: InventoryItem, movement_type: str, qty: float) -> None:
    qty = float(qty)
    if movement_type == "in":
        item.quantity = (item.quantity or 0.0) + qty
    elif movement_type in ("out", "waste"):
        item.quantity = max((item.quantity or 0.0) - qty, 0.0)
    elif movement_type == "adjust":
        item.quantity = max(qty, 0.0)

def can_make_menu_item(db: Session, menu_item_id: str, qty: int) -> bool:
    recipe = db.query(RecipeIngredient).filter(RecipeIngredient.menu_item_id == menu_item_id).all()
    if not recipe:
        return True
    for r in recipe:
        inv = db.get(InventoryItem, r.inventory_item_id)
        need = (r.quantity_per_unit or 0.0) * qty
        if (not inv) or ((inv.quantity or 0.0) < need):
            return False
    return True

def low_stock_list(db: Session) -> List[InventoryItem]:
    return (
        db.query(InventoryItem)
        .filter(InventoryItem.quantity < InventoryItem.min_quantity)
        .order_by((InventoryItem.min_quantity - InventoryItem.quantity).desc())
        .all()
    )

def deduct_inventory_for_items(db: Session, order_items: List[OrderItem]) -> None:
    if not order_items:
        return
    for oi in order_items:
        recipe_rows = db.query(RecipeIngredient).filter(RecipeIngredient.menu_item_id == oi.menu_item_id).all()
        for r in recipe_rows:
            inv = db.get(InventoryItem, r.inventory_item_id)
            if not inv:
                continue
            used = (r.quantity_per_unit or 0.0) * oi.quantity
            inv.quantity = max((inv.quantity or 0.0) - used, 0.0)

async def broadcast_low_stock(db: Session) -> None:
    lows = low_stock_list(db)
    await ws_manager.broadcast(ws_json({
        "type": "low_stock",
        "items": [
            {
                "id": i.id,
                "name": i.name,
                "qty": float(i.quantity or 0.0),
                "min": float(i.min_quantity or 0.0),
                "to_buy": float((i.min_quantity or 0.0) - (i.quantity or 0.0)),
                "unit": i.unit,
            } for i in lows
        ]
    }))

def set_order_status_timestamps(order: Order, new_status: str) -> None:
    now = datetime.utcnow()
    if new_status == "cooking" and not order.cooking_at:
        order.cooking_at = now
    elif new_status == "ready" and not order.ready_at:
        order.ready_at = now
    elif new_status == "delivered" and not order.delivered_at:
        order.delivered_at = now

# ---------------------------------------------------------------------------
# STARTUP & SEED
# ---------------------------------------------------------------------------

def seed_initial_data(db: Session) -> None:
    # 1. System Users
    if db.query(SystemUser).count() == 0:
        db.add_all([
            SystemUser(username="admin",   password="admin123",   role="admin"),
            SystemUser(username="manager", password="manager123", role="manager"),
            SystemUser(username="waiter",  password="waiter123",  role="waiter"),
            SystemUser(username="chef",    password="chef123",    role="chef"),
        ])
        db.commit()

    # 2. Employees
    if db.query(Employee).count() == 0:
        db.add_all([
            Employee(id="1", username="waiter",  role="waiter",  hourly_rate=1500),
            Employee(id="2", username="manager", role="manager", hourly_rate=2000), 
            Employee(id="3", username="chef",    role="chef",    hourly_rate=2500),
            Employee(id="4", username="admin",   role="admin",   hourly_rate=3000),
        ])
        db.commit()

    # 3. Tables
    if db.query(Table).count() == 0:
        db.add_all([
            Table(id="1", room="Негізгі зал", number=1),
            Table(id="2", room="Негізгі зал", number=2),
            Table(id="3", room="Негізгі зал", number=3),
            Table(id="4", room="Негізгі зал", number=4),
            Table(id="5", room="VIP зал",     number=5),
            Table(id="6", room="VIP зал",     number=6),
            Table(id="7", room="Терраса",     number=7),
            Table(id="8", room="Терраса",     number=8),
        ])
        db.commit()

    # 4. Suppliers
    if db.query(Supplier).count() == 0:
        db.add(Supplier(name="Fresh Food Ltd.", phone="+77011234567"))
        db.commit()

@app.on_event("startup")
def on_startup() -> None:
    # WARNING: Do not drop tables in production.
    # Base.metadata.drop_all(bind=engine) 
    
    Base.metadata.create_all(bind=engine)
    
    db = SessionLocal()
    try:
        seed_initial_data(db)
    finally:
        db.close()
    
    print("--- СЕРВЕР ЗАПУЩЕН ---")

# ---------------------------------------------------------------------------
# HEALTH & AUTH
# ---------------------------------------------------------------------------

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/set-lang/{lang_code}")
def set_lang(lang_code: str, request: Request):
    lang_code = lang_code.lower()
    if lang_code not in ("kk", "ru", "en"):
        raise HTTPException(status_code=400, detail="Unsupported language")
    referer = request.headers.get("referer") or "/"
    response = RedirectResponse(url=referer, status_code=302)
    response.set_cookie("lang", lang_code, max_age=60 * 60 * 24 * 365)
    return response

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    lang = get_lang(request)
    user = get_current_user(request)
    if user:
        role = user.get("role")
        return RedirectResponse(url=f"/{role}" if role in ("admin", "manager", "waiter", "chef") else "/user", status_code=302)

    return templates.TemplateResponse(
        "index.html",
        {"request": request, "view": "login", "lang": lang, "current_user": None, "login_error": None},
    )

@app.post("/login", response_class=HTMLResponse)
async def login_submit(
    request: Request,
    db: Session = Depends(get_db),
    username: str = Form(...),
    password: str = Form(...),
):
    lang = get_lang(request)
    user_db = db.query(SystemUser).filter(SystemUser.username == username).first()
    if not user_db or user_db.password != password:
        return templates.TemplateResponse(
            "index.html",
            {"request": request, "view": "login", "lang": lang, "current_user": None, "login_error": "Қате логин немесе құпиясөз"},
        )

    request.session["user"] = {"id": user_db.id, "username": user_db.username, "role": user_db.role}
    role = user_db.role
    url = f"/{role}" if role in ("admin", "manager", "waiter", "chef") else "/user"
    return RedirectResponse(url=url, status_code=302)

@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse(url="/login", status_code=302)

@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request):
    lang = get_lang(request)
    return templates.TemplateResponse("index.html", {"request": request, "view": "register", "lang": lang})

@app.post("/register", response_class=HTMLResponse)
async def register_submit(
    request: Request,
    db: Session = Depends(get_db),
    username: str = Form(...),
    password: str = Form(...),
):
    if db.query(SystemUser).filter(SystemUser.username == username).first():
         return templates.TemplateResponse("index.html", {"request": request, "view": "register", "register_error": "User exists"})
    
    new_user = SystemUser(username=username, password=password, role="waiter")
    db.add(new_user)
    db.commit()
    return RedirectResponse(url="/login", status_code=302)

# ---------------------------------------------------------------------------
# ROOT
# ---------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
def root(request: Request):
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/login", status_code=302)

    role = user.get("role")
    if role in ("admin", "manager", "waiter", "chef"):
        return RedirectResponse(url=f"/{role}", status_code=302)
    return RedirectResponse(url="/user", status_code=302)

# ---------------------------------------------------------------------------
# MANAGER
# ---------------------------------------------------------------------------

@app.get("/manager", response_class=HTMLResponse)
def manager_page(
    request: Request,
    db: Session = Depends(get_db),
    user=Depends(require_role(["manager", "admin"])),
):
    lang = get_lang(request)
    
    # Statistics
    total_orders = db.query(func.count(Order.id)).scalar() or 0
    active_orders = db.query(func.count(Order.id)).filter(Order.status != "delivered").scalar() or 0
    free_tables = db.query(func.count(Table.id)).filter(Table.status == "free").scalar() or 0
    
    payroll_all = db.query(PayrollRecord).all()
    revenue_total = sum(p.total_amount for p in payroll_all) # Placeholder, ideally from DailyReport or Orders
    
    # Better revenue calc from Today's orders
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0)
    today_orders = db.query(Order).filter(Order.created_at >= today_start).all()
    revenue_today = sum(o.final_amount or 0 for o in today_orders)

    latest_orders = db.query(Order).options(selectinload(Order.table)).order_by(Order.created_at.desc()).limit(10).all()
    lows = low_stock_list(db)

    # Shift
    emp = get_employee_for_session_user(db, user)
    current_shift = get_current_shift(db, emp.id) if emp else None

    # Data lists
    suppliers = db.query(Supplier).order_by(Supplier.name.asc()).all()
    purchase_orders = db.query(PurchaseOrder).options(selectinload(PurchaseOrder.supplier)).order_by(PurchaseOrder.created_at.desc()).limit(50).all()
    menu_items = db.query(MenuItem).order_by(MenuItem.category, MenuItem.name).all()
    inventory_items = db.query(InventoryItem).order_by(InventoryItem.name.asc()).all()
    reservations = db.query(Reservation).filter(Reservation.status == "active").order_by(Reservation.time_start.asc()).all()

    stats = {
        "revenue_total": revenue_today,
        "active_orders": active_orders,
        "free_tables": free_tables,
    }

    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "view": "manager",
            "lang": lang,
            "current_user": user,
            "stats": stats,
            "latest_orders": latest_orders,
            "low_stock": lows,
            "current_shift": current_shift,
            "suppliers": suppliers,
            "purchase_orders": purchase_orders,
            "menu_items": menu_items,       
            "inventory_items": inventory_items,
            "reservations": reservations,
        }
    )

@app.get("/manager/menu-analysis", response_class=HTMLResponse)
def menu_analysis(
    request: Request,
    db: Session = Depends(get_db),
    user=Depends(require_perm("analytics.view"))
):
    lang = get_lang(request)
    menu_items = db.query(MenuItem).options(selectinload(MenuItem.recipe_items).selectinload(RecipeIngredient.inventory_item)).all()
    
    analysis = []
    for m in menu_items:
        cost_price = 0.0
        for r in m.recipe_items:
            if r.inventory_item and r.inventory_item.cost_per_unit:
                cost_price += r.quantity_per_unit * r.inventory_item.cost_per_unit
        
        profit = m.price - cost_price
        margin_percent = int((profit / m.price) * 100) if m.price > 0 else 0
            
        analysis.append({
            "name": m.name,
            "category": m.category,
            "price": m.price,
            "cost": round(cost_price, 2),
            "profit": round(profit, 2),
            "margin": margin_percent
        })
    
    analysis.sort(key=lambda x: x["profit"], reverse=True)
    return templates.TemplateResponse("index.html", {"request": request, "view": "menu_analysis", "lang": lang, "current_user": user, "analysis": analysis})

@app.post("/manager/close_day", response_class=RedirectResponse)
def manager_close_day(request: Request, db: Session = Depends(get_db), user=Depends(require_role(["manager", "admin"]))):
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0)
    orders = db.query(Order).filter(Order.created_at >= today_start).all()
    
    revenue = sum(o.final_amount or 0 for o in orders)
    bonuses = sum(o.discount_amount or 0 for o in orders)
    
    db.add(DailyReport(date=datetime.utcnow().date(), total_revenue=revenue, bonuses_used=bonuses, orders_count=len(orders)))
    db.commit()
    return RedirectResponse(url="/manager", status_code=302)

@app.post("/manager/inventory/update", response_class=RedirectResponse)
async def manager_inventory_update(
    item_id: int = Form(...),
    quantity: float = Form(...),
    db: Session = Depends(get_db),
    user=Depends(require_perm("inventory.move")),
):
    item = db.get(InventoryItem, item_id)
    if item:
        apply_movement(item, "adjust", quantity)
        db.add(InventoryMovement(item_id=item.id, movement_type="adjust", quantity=float(quantity), reason="Manual update", created_by=user.get("username")))
        db.commit()
        await broadcast_low_stock(db)
    return RedirectResponse(url="/manager", status_code=302)

@app.post("/manager/inventory/waste", response_class=RedirectResponse)
async def manager_inventory_waste(
    item_id: int = Form(...),
    quantity: float = Form(...),
    reason: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(require_perm("inventory.move")),
):
    item = db.get(InventoryItem, item_id)
    if item:
        apply_movement(item, "waste", quantity)
        db.add(InventoryMovement(item_id=item.id, movement_type="waste", quantity=float(quantity), reason=reason, created_by=user.get("username")))
        db.commit()
        await broadcast_low_stock(db)
    return RedirectResponse(url="/manager", status_code=302)

@app.post("/manager/create_reservation", response_class=RedirectResponse)
def create_reservation(
    name: str = Form(...),
    phone: str = Form(...),
    date_time: str = Form(...),
    guests: int = Form(2),
    comment: str = Form(""),
    db: Session = Depends(get_db),
    user=Depends(require_role(["manager", "admin"])),
):
    try:
        dt_obj = datetime.strptime(date_time, "%Y-%m-%dT%H:%M")
        db.add(Reservation(customer_name=name, customer_phone=phone, time_start=dt_obj, guests_count=guests, comment=comment))
        db.commit()
    except Exception:
        pass
    return RedirectResponse(url="/manager", status_code=302)

# ---------------------------------------------------------------------------
# PURCHASE ORDERS
# ---------------------------------------------------------------------------

@app.post("/purchase-orders", response_class=RedirectResponse)
async def create_po_html(
    request: Request,
    db: Session = Depends(get_db),
    user=Depends(require_perm("po.manage"))
):
    form = await request.form()
    supplier_id = form.get("supplier_id")
    if not supplier_id:
        return RedirectResponse(url="/manager", status_code=302)

    items_to_order = []
    for key, value in form.items():
        if key.startswith("qty_") and value:
            try:
                qty = float(value)
                if qty > 0:
                    items_to_order.append({"item_id": int(key.split("_")[1]), "quantity": qty})
            except: continue

    if items_to_order:
        po = PurchaseOrder(supplier_id=int(supplier_id), status="ordered", created_at=datetime.utcnow())
        db.add(po)
        db.commit()
        db.refresh(po)
        for item in items_to_order:
            db.add(PurchaseOrderItem(po_id=po.id, item_id=item["item_id"], quantity=item["quantity"], price_per_unit=0.0))
        db.commit()
    
    return RedirectResponse(url="/manager", status_code=302)

@app.post("/purchase-orders/{po_id}/receive", response_class=RedirectResponse)
async def receive_po_html(
    po_id: int, 
    db: Session = Depends(get_db), 
    user=Depends(require_perm("po.manage"))
):
    po = db.query(PurchaseOrder).options(selectinload(PurchaseOrder.items)).filter(PurchaseOrder.id == po_id).first()
    if po and po.status != "received":
        po.status = "received"
        po.received_at = datetime.utcnow()
        for it in po.items:
            inv = db.get(InventoryItem, it.item_id)
            if inv:
                apply_movement(inv, "in", it.quantity)
                db.add(InventoryMovement(item_id=inv.id, movement_type="in", quantity=it.quantity, reason=f"PO #{po.id}", created_by=user.get("username")))
        db.commit()
        await ws_manager.broadcast(ws_json({"type": "po_received", "po_id": po.id}))
        await broadcast_low_stock(db)
    
    return RedirectResponse(url="/manager", status_code=302)

# ---------------------------------------------------------------------------
# WAITER
# ---------------------------------------------------------------------------

@app.get("/waiter", response_class=HTMLResponse)
def waiter_page(
    request: Request,
    table_id: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    user=Depends(require_role(["waiter", "manager", "admin"])),
):
    lang = get_lang(request)
    tables = db.query(Table).order_by(Table.room.asc(), Table.number.asc()).all()
    menu = db.query(MenuItem).order_by(MenuItem.category.asc(), MenuItem.name.asc()).all()
    availability = {m.id: can_make_menu_item(db, m.id, 1) for m in menu}
    orders = db.query(Order).options(selectinload(Order.items).selectinload(OrderItem.menu_item), selectinload(Order.table)).filter(Order.status != "delivered").order_by(Order.created_at.desc()).all()
    
    active_table = db.get(Table, table_id) if table_id else None
    emp = get_employee_for_session_user(db, user)
    current_shift = get_current_shift(db, emp.id) if emp else None

    return templates.TemplateResponse("index.html", {
        "request": request,
        "view": "waiter",
        "tables": tables,
        "menu": menu,
        "orders": orders,
        "active_table": active_table,
        "availability": availability,
        "lang": lang,
        "current_user": user,
        "current_shift": current_shift,
    })

@app.post("/waiter/create_order", response_class=RedirectResponse)
async def waiter_create_order(
    request: Request,
    table_id: str = Form(...),
    waiter_name: str = Form(...),
    customer_phone: Optional[str] = Form(None),
    use_bonuses: bool = Form(False),
    db: Session = Depends(get_db),
    user=Depends(require_perm("orders.create")),
):
    # 1. Customer
    customer_obj = None
    if customer_phone and len(customer_phone.strip()) > 5:
        phone_clean = customer_phone.strip()
        customer_obj = db.query(Customer).filter(Customer.phone == phone_clean).first()
        if not customer_obj:
            customer_obj = Customer(phone=phone_clean, name="Guest", visits_count=0)
            db.add(customer_obj)
            db.commit()
            db.refresh(customer_obj)
        customer_obj.visits_count += 1
        customer_obj.last_visit = datetime.now().date()

    # 2. Items
    form = await request.form()
    items_payload = []
    for key, value in form.items():
        if key.startswith("qty_"):
            try:
                qty = int(value)
                if qty > 0:
                    items_payload.append({"menu_id": key[4:], "qty": qty})
            except: pass

    if not items_payload:
        return RedirectResponse(url=f"/waiter?table_id={table_id}", status_code=302)

    # 3. Calc
    total_price = 0
    order_items_objects = []
    
    for it in items_payload:
        menu_item = db.get(MenuItem, it["menu_id"])
        if not menu_item: continue
        
        if not can_make_menu_item(db, menu_item.id, it["qty"]):
             return RedirectResponse(url=f"/waiter?table_id={table_id}&stoplist=1", status_code=302)
        
        item_price = menu_item.price
        if menu_item.discount_percent > 0:
            item_price = int(menu_item.price * (100 - menu_item.discount_percent) / 100)
            
        total_price += item_price * it["qty"]
        order_items_objects.append(OrderItem(menu_item_id=menu_item.id, quantity=it["qty"]))
        
    discount = 0
    if use_bonuses and customer_obj and customer_obj.bonus_balance > 0:
        discount = min(total_price, customer_obj.bonus_balance)
        customer_obj.bonus_balance -= discount

    final_price = total_price - discount
    if customer_obj:
        customer_obj.bonus_balance += int(final_price * 0.05) # 5% cashback

    # 4. Save
    order_id = f"ord-{int(time.time() * 1000)}"
    order = Order(
        id=order_id,
        table_id=table_id,
        customer_id=customer_obj.id if customer_obj else None,
        status="new",
        waiter_name=waiter_name,
        total_amount=total_price,
        discount_amount=discount,
        final_amount=final_price
    )
    order.items = order_items_objects
    db.add(order)

    table = db.get(Table, table_id)
    if table:
        table.status = "occupied"
        table.current_order_id = order_id
    
    deduct_inventory_for_items(db, order_items_objects)
    db.commit()

    await ws_manager.broadcast(ws_json({"type": "new_order", "order_id": order.id, "table_id": order.table_id}))
    return RedirectResponse(url=f"/waiter?table_id={table_id}", status_code=302)

@app.post("/waiter/update_order_status", response_class=RedirectResponse)
async def waiter_update_order_status(
    order_id: str = Form(...),
    status_value: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(require_perm("orders.status")),
):
    order = db.get(Order, order_id)
    if order:
        order.status = status_value
        set_order_status_timestamps(order, status_value)
        if status_value == "delivered":
            table = db.get(Table, order.table_id)
            if table:
                table.status = "free"
                table.current_order_id = None
        db.commit()
        await ws_manager.broadcast(ws_json({"type": "order_status", "order_id": order.id, "status": order.status}))
    return RedirectResponse(url="/waiter", status_code=302)

@app.post("/waiter/update_table_status", response_class=RedirectResponse)
async def waiter_update_table_status(
    table_id: str = Form(...),
    status_value: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(require_perm("tables.status")),
):
    table = db.get(Table, table_id)
    if table:
        table.status = status_value
        if status_value == "free":
            table.current_order_id = None
        db.commit()
        await ws_manager.broadcast(ws_json({"type": "table_status", "table_id": table.id, "status": table.status}))
    return RedirectResponse(url="/waiter", status_code=302)

# ---------------------------------------------------------------------------
# CHEF
# ---------------------------------------------------------------------------

@app.get("/chef", response_class=HTMLResponse)
def chef_page(
    request: Request,
    db: Session = Depends(get_db),
    user=Depends(require_role(["chef", "manager", "admin"])),
):
    lang = get_lang(request)
    orders = db.query(Order).options(selectinload(Order.items).selectinload(OrderItem.menu_item), selectinload(Order.table)).filter(Order.status.in_(["new", "cooking", "ready"])).order_by(Order.created_at.asc()).all()
    emp = get_employee_for_session_user(db, user)
    current_shift = get_current_shift(db, emp.id) if emp else None

    return templates.TemplateResponse("index.html", {
        "request": request, 
        "view": "chef", 
        "orders": orders, 
        "lang": lang, 
        "current_user": user,
        "current_shift": current_shift,
    })

@app.post("/chef/update_order_status", response_class=RedirectResponse)
async def chef_update_order_status(
    order_id: str = Form(...),
    status_value: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(require_perm("orders.status")),
):
    order = db.get(Order, order_id)
    if order:
        order.status = status_value
        set_order_status_timestamps(order, status_value)
        db.commit()
        await ws_manager.broadcast(ws_json({
            "type": "order_status", 
            "order_id": order.id, 
            "table_id": order.table_id,
            "status": order.status
        }))
    return RedirectResponse(url="/chef", status_code=302)

# ---------------------------------------------------------------------------
# ADMIN
# ---------------------------------------------------------------------------

@app.get("/admin", response_class=HTMLResponse)
def admin_page(request: Request, db: Session = Depends(get_db), user=Depends(require_role(["admin"]))):
    lang = get_lang(request)
    employees = db.query(Employee).order_by(Employee.username).all()
    payroll = db.query(PayrollRecord).order_by(PayrollRecord.period_end.desc()).limit(50).all()
    tables = db.query(Table).all()
    menu_items = db.query(MenuItem).order_by(MenuItem.category, MenuItem.name).all()
    
    # Chart Data
    since = datetime.utcnow() - timedelta(days=7)
    revenue_data = db.query(func.date(DailyReport.date), func.sum(DailyReport.total_revenue)).filter(DailyReport.date >= since.date()).group_by(func.date(DailyReport.date)).order_by(func.date(DailyReport.date)).all()
    chart_labels = [r[0].strftime('%d.%m') for r in revenue_data] if revenue_data else ["No Data"]
    chart_values = [int(r[1]) for r in revenue_data] if revenue_data else [0]

    return templates.TemplateResponse("index.html", {
        "request": request, "view": "admin", "lang": lang, "current_user": user, 
        "employees": employees, "payroll": payroll, "menu_items": menu_items,       
        "tables": tables, "chart_labels": chart_labels, "chart_values": chart_values    
    })

@app.post("/admin/menu/create", response_class=RedirectResponse)
def admin_create_menu(
    name: str = Form(...),
    category: str = Form(...),
    price: int = Form(...),
    description: str = Form(""),
    discount_percent: int = Form(0),
    db: Session = Depends(get_db)
):
    db.add(MenuItem(id=f"m{int(time.time())}", name=name, category=category, price=price, description=description, discount_percent=discount_percent))
    db.commit()
    return RedirectResponse(url="/admin", status_code=302)

@app.post("/admin/menu/delete", response_class=RedirectResponse)
def admin_delete_menu_item(menu_id: str = Form(...), db: Session = Depends(get_db), user=Depends(require_role(["admin"]))):
    item = db.get(MenuItem, menu_id)
    if item:
        db.delete(item)
        db.commit()
    return RedirectResponse(url="/admin", status_code=302)

@app.post("/admin/menu/update_discount", response_class=RedirectResponse)
def admin_update_discount(menu_id: str = Form(...), discount: int = Form(...), db: Session = Depends(get_db), user=Depends(require_role(["admin"]))):
    item = db.get(MenuItem, menu_id)
    if item:
        item.discount_percent = discount
        db.commit()
    return RedirectResponse(url="/admin", status_code=302)

@app.post("/admin/menu/upload_image", response_class=RedirectResponse)
async def upload_menu_image(
    request: Request,  # <--- ОСЫНЫ ҚОСУ КЕРЕК
    menu_id: str = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    user=Depends(require_role(["admin", "manager"]))
):
    os.makedirs("static/images", exist_ok=True)
    file_location = f"static/images/{menu_id}_{int(time.time())}.jpg"
    with open(file_location, "wb+") as file_object:
        shutil.copyfileobj(file.file, file_object)
    
    item = db.get(MenuItem, menu_id)
    if item:
        item.image = "/" + file_location
        db.commit()
    
    # Енді request объектісі FastAPI-ден келеді және қате шықпайды
    return RedirectResponse(url=request.headers.get("referer") or "/admin", status_code=302)

class TablePosition(BaseModel):
    id: str
    x: int
    y: int

@app.post("/admin/tables/save_layout", response_class=JSONResponse)
async def save_table_layout(positions: List[TablePosition], db: Session = Depends(get_db), user=Depends(require_role(["admin", "manager"]))):
    for pos in positions:
        table = db.get(Table, pos.id)
        if table:
            table.x = pos.x
            table.y = pos.y
    db.commit()
    return {"status": "ok"}

@app.post("/admin/create_user", response_class=RedirectResponse)
def admin_create_user(
    username: str = Form(...),
    password: str = Form(...),
    role: str = Form(...),
    hourly_rate: int = Form(...),
    db: Session = Depends(get_db),
    user=Depends(require_perm("users.manage")),
):
    if not db.query(SystemUser).filter(SystemUser.username == username).first():
        db.add(SystemUser(username=username, password=password, role=role))
        db.add(Employee(id=f"emp-{int(time.time()*1000)}", username=username, role=role, hourly_rate=hourly_rate))
        db.commit()
    return RedirectResponse(url="/admin", status_code=302)

@app.post("/admin/delete_user", response_class=RedirectResponse)
def admin_delete_user(user_id: str = Form(...), db: Session = Depends(get_db), user=Depends(require_role(["admin"]))):
    emp = db.get(Employee, user_id)
    if emp:
        sys_user = db.query(SystemUser).filter(SystemUser.username == emp.username).first()
        if sys_user: db.delete(sys_user)
        db.delete(emp)
        db.commit()
    return RedirectResponse(url="/admin", status_code=302)

@app.post("/admin/update_user_role", response_class=RedirectResponse)
def admin_update_user_role(user_id: str = Form(...), role: str = Form(...), db: Session = Depends(get_db), user=Depends(require_perm("users.manage"))):
    emp = db.get(Employee, user_id)
    if emp:
        emp.role = role
        su = db.query(SystemUser).filter(SystemUser.username == emp.username).first()
        if su: su.role = role
        db.commit()
    return RedirectResponse(url="/admin", status_code=302)

@app.post("/admin/generate_payroll", response_class=RedirectResponse)
def admin_generate_payroll(user_id: str = Form(...), db: Session = Depends(get_db), user=Depends(require_perm("payroll.edit"))):
    emp = db.get(Employee, user_id)
    if emp:
        end = datetime.utcnow().date()
        start = end - timedelta(days=30)
        rows = db.query(Attendance).filter(Attendance.user_id == emp.id, Attendance.date >= start, Attendance.date <= end).all()
        total_hours = sum(r.total_hours for r in rows)
        db.add(PayrollRecord(
            id=f"pay-{int(time.time() * 1000)}", user_id=emp.id, username=emp.username,
            period_start=start, period_end=end, total_hours=total_hours,
            total_amount=int(total_hours * emp.hourly_rate), status="pending"
        ))
        db.commit()
    return RedirectResponse(url="/admin", status_code=302)

@app.post("/admin/update_payroll_status", response_class=RedirectResponse)
def admin_update_payroll_status(payroll_id: str = Form(...), status_value: str = Form(...), db: Session = Depends(get_db), user=Depends(require_perm("payroll.edit"))):
    pr = db.get(PayrollRecord, payroll_id)
    if pr:
        pr.status = status_value
        db.commit()
    return RedirectResponse(url="/admin", status_code=302)

@app.post("/admin/staff/announce", response_class=RedirectResponse)
async def create_announcement(message: str = Form(...), db: Session = Depends(get_db), user=Depends(require_role(["admin"]))):
    db.add(Announcement(message=message))
    db.commit()
    await ws_manager.broadcast(ws_json({"type": "announcement", "message": message}))
    return RedirectResponse(url="/admin", status_code=302)

@app.post("/admin/marketing/create_promo", response_class=RedirectResponse)
def create_promotion(title: str = Form(...), description: str = Form(""), db: Session = Depends(get_db), user=Depends(require_role(["admin"]))):
    db.add(Promotion(title=title, description=description))
    db.commit()
    return RedirectResponse(url="/admin", status_code=302)

# ---------------------------------------------------------------------------
# CLIENT / QR
# ---------------------------------------------------------------------------

@app.get("/user", response_class=HTMLResponse)
def user_page(request: Request, db: Session = Depends(get_db)):
    lang = get_lang(request)
    popular_menu = db.query(MenuItem).filter(MenuItem.popular == True).all()
    all_menu = db.query(MenuItem).order_by(MenuItem.category.asc(), MenuItem.name.asc()).all()
    return templates.TemplateResponse("index.html", {"request": request, "view": "user", "lang": lang, "popular_menu": popular_menu, "all_menu": all_menu})

@app.get("/qr/{table_id}", response_class=HTMLResponse)
def qr_order_page(table_id: str, request: Request, db: Session = Depends(get_db)):
    lang = get_lang(request)
    table = db.get(Table, table_id)
    if not table:
        raise HTTPException(status_code=404, detail="Table not found")
    menu = db.query(MenuItem).order_by(MenuItem.category.asc(), MenuItem.name.asc()).all()
    availability = {m.id: can_make_menu_item(db, m.id, 1) for m in menu}
    return templates.TemplateResponse("index.html", {"request": request, "view": "qr_order", "lang": lang, "table": table, "menu": menu, "availability": availability, "qr_success": False})

@app.post("/qr/order", response_class=HTMLResponse)
async def qr_create_order(
    request: Request,
    table_id: str = Form(...),
    guest_name: str = Form("Guest"),
    db: Session = Depends(get_db),
):
    table = db.get(Table, table_id)
    if not table: return RedirectResponse(url=f"/qr/{table_id}", status_code=302)

    form = await request.form()
    items_payload = []
    total_price = 0
    order_items = []

    for key, value in form.items():
        if key.startswith("qty_"):
            try:
                qty = int(value)
                if qty > 0:
                    m_id = key[4:]
                    m_item = db.get(MenuItem, m_id)
                    if m_item and can_make_menu_item(db, m_id, qty):
                        items_payload.append(m_item)
                        # Discount logic for QR too
                        p = m_item.price
                        if m_item.discount_percent > 0:
                            p = int(m_item.price * (100 - m_item.discount_percent) / 100)
                        total_price += p * qty
                        order_items.append(OrderItem(menu_item_id=m_id, quantity=qty))
            except: pass

    if not order_items:
         return RedirectResponse(url=f"/qr/{table_id}", status_code=302)

    order = Order(
        id=f"ord-{int(time.time() * 1000)}",
        table_id=table_id,
        status="new",
        waiter_name=f"QR-{guest_name}",
        total_amount=total_price,
        final_amount=total_price
    )
    order.items = order_items
    db.add(order)
    
    table.status = "occupied"
    table.current_order_id = order.id
    
    deduct_inventory_for_items(db, order_items)
    db.commit()

    await ws_manager.broadcast(ws_json({"type": "new_order", "order_id": order.id, "table_id": order.table_id}))
    return templates.TemplateResponse("index.html", {
        "request": request, "view": "qr_order", "lang": get_lang(request), 
        "table": table, "menu": db.query(MenuItem).all(), "availability": {}, "qr_success": True
    })

@app.get("/order/{order_id}/print", response_class=HTMLResponse)
def print_receipt(order_id: str, db: Session = Depends(get_db)):
    order = db.query(Order).options(selectinload(Order.items).selectinload(OrderItem.menu_item)).filter(Order.id == order_id).first()
    if not order: return "Order not found"
    
    html = f"""<html><body onload="window.print()" style="font-family:monospace;width:300px;margin:0 auto">
    <h2 style="text-align:center">TURAN CRM</h2>
    <div style="border-bottom:1px dashed #000;margin:10px 0"></div>
    <p>Order: #{order.id[-6:]}<br>Table: {order.table_id}<br>Waiter: {order.waiter_name}</p>
    <div style="border-bottom:1px dashed #000;margin:10px 0"></div>"""
    
    for item in order.items:
        html += f"<div style='display:flex;justify-content:space-between'><span>{item.menu_item.name} x{item.quantity}</span><span>{item.menu_item.price * item.quantity}</span></div>"
    
    html += f"""<div style="border-bottom:1px dashed #000;margin:10px 0"></div>
    <div style="display:flex;justify-content:space-between;font-weight:bold"><span>TOTAL:</span><span>{order.final_amount} ₸</span></div>
    </body></html>"""
    return html

# ---------------------------------------------------------------------------
# SHIFTS
# ---------------------------------------------------------------------------

@app.post("/shift/checkin", response_class=RedirectResponse)
def shift_checkin(request: Request, db: Session = Depends(get_db), user=Depends(require_perm("shift.self"))):
    emp = get_employee_for_session_user(db, user)
    if emp:
        if not db.query(Shift).filter(Shift.user_id == emp.id, Shift.status == "open").first():
            db.add(Shift(user_id=emp.id, start_at=datetime.utcnow(), status="open"))
            db.commit()
    return RedirectResponse(url=request.headers.get("referer") or "/", status_code=302)

@app.post("/shift/checkout", response_class=RedirectResponse)
def shift_checkout(request: Request, db: Session = Depends(get_db), user=Depends(require_perm("shift.self"))):
    emp = get_employee_for_session_user(db, user)
    if emp:
        sh = db.query(Shift).filter(Shift.user_id == emp.id, Shift.status == "open").first()
        if sh:
            sh.end_at = datetime.utcnow()
            sh.status = "closed"
            hours = max((sh.end_at - sh.start_at).total_seconds() / 3600.0, 0.0)
            
            # Update Attendance
            att = db.query(Attendance).filter(Attendance.user_id == emp.id, Attendance.date == sh.start_at.date()).first()
            if att:
                att.total_hours += hours
            else:
                db.add(Attendance(id=f"att-{int(time.time()*1000)}", user_id=emp.id, date=sh.start_at.date(), total_hours=hours))
            db.commit()
    return RedirectResponse(url=request.headers.get("referer") or "/", status_code=302)

# ---------------------------------------------------------------------------
# RUNNER
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import uvicorn
    # Use "main:app" for reload to work correctly
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)